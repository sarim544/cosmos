# twitter-login
A simple code implemention for twitter login using php and oauth 1.0

Demo : http://packetcode.com/apps/twitter-login/
Video Tutorial : http://youtu.be/D8pO7tbYlBk
